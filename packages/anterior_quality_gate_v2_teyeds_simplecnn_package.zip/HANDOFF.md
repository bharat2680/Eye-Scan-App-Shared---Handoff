# anterior_quality_gate_v2_teyeds_simplecnn

## Files

- `best_model.keras`
- `label_map.json`
- `train_config.json`
- `metrics.json`
- `inference_contract.json`

## Intended use

Use before the anterior surface router as an evaluation-only recapture gate.
This model separates:

- `good_capture`
- `needs_recapture`

It is intended to reduce obviously weak anterior frames before downstream
screening. It is not a disease classifier.

## Preprocessing

- color mode: RGB
- input size: `224 x 224`
- resize: direct resize to `224 x 224`
- dtype: `float32`
- normalization: the model includes `Rescaling(1.0 / 255.0)` internally, so
  pass raw RGB image values and do not normalize twice upstream

## Decision rule

- threshold-tuned binary decision on `p(needs_recapture)`
- selected threshold: `0.35`
- if the threshold is not met, treat the image as `good_capture`

## Metrics summary

- validation:
  default `val_accuracy=0.8413`, `val_loss=0.4544`
  threshold-tuned `balanced_accuracy=0.8100`
- test:
  default `test_accuracy=0.8256`
  default confusion matrix: `[[111, 9], [25, 50]]`
  threshold-tuned `test_accuracy=0.8103`
  threshold-tuned confusion matrix: `[[102, 18], [19, 56]]`
- recapture class:
  threshold-tuned `needs_recapture` recall `0.7467`

## Known failure modes

- trained from TEyeDS validity-derived labels, not from your app's own
  real-world recapture decisions
- current negative class mostly reflects visibility or annotation failure, not
  every kind of real smartphone capture problem
- should remain `evaluation_only` until checked against real EyeScan app
  captures from your Mac/iPhone flow
