# anterior_uveitis_vs_normal_v1_simplecnn

## Files

- `best_model.keras`
- `label_map.json`
- `train_config.json`
- `metrics.json`
- `inference_contract.json`

## Intended use

Use only after the anterior quality gate and only on images already classified
as `surface_abnormal` by the current surface model. This model separates:

- `uveitis`
- `normal`

It is intended to narrow some inflammatory-looking surface-positive cases. It
is not a general anterior disease classifier.

## Preprocessing

- color mode: RGB
- input size: `224 x 224`
- resize: direct resize to `224 x 224`
- dtype: `float32`
- normalization: the model includes `Rescaling(1.0 / 255.0)` internally, so
  pass raw RGB image values and do not normalize twice upstream

## Decision rule

- recommended positive label: `uveitis`
- recommended threshold: `0.5` on `p(uveitis)`
- threshold selected on validation split for balanced accuracy
- fallback if threshold logic is unavailable: `argmax`

## Metrics summary

- validation: `val_accuracy=0.9792`, `val_loss=0.1344`
- threshold-tuned validation balanced accuracy: `0.9846`
- default test: `test_accuracy=0.9846`
- default test confusion matrix: `[[96, 1], [1, 32]]`
- threshold-tuned test: `test_accuracy=0.9846`
- threshold-tuned test confusion matrix: `[[96, 1], [1, 32]]`

## Known failure modes

- trained on one local source only, without an external clinical holdout
- likely overlap with other red-eye causes that are not labeled separately in
  this dataset
- should only narrow some `surface_abnormal` cases and should still be treated
  as an evaluation artifact
