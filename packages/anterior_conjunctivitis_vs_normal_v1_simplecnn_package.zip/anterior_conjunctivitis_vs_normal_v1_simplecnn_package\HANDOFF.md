# anterior_conjunctivitis_vs_normal_v1_simplecnn

## Files

- `best_model.keras`
- `label_map.json`
- `train_config.json`
- `metrics.json`
- `inference_contract.json`

## Intended use

Use only after the anterior quality gate and only on images already classified
as `surface_abnormal` by the current surface model. This model separates:

- `conjunctivitis`
- `normal`

It is intended to make some surface-positive results more specific. It is not a
general anterior disease classifier.

## Preprocessing

- color mode: RGB
- input size: `224 x 224`
- resize: direct resize to `224 x 224`
- dtype: `float32`
- normalization: the model includes `Rescaling(1.0 / 255.0)` internally, so
  pass raw RGB image values and do not normalize twice upstream

## Decision rule

- recommended positive label: `conjunctivitis`
- recommended threshold: `0.15` on `p(conjunctivitis)`
- threshold selected on validation split for balanced accuracy
- fallback if threshold logic is unavailable: `argmax`

## Metrics summary

- validation: `val_accuracy=0.9875`, `val_loss=0.0920`
- threshold-tuned validation balanced accuracy: `0.9897`
- default test: `test_accuracy=0.9669`
- default test confusion matrix: `[[49, 5], [0, 97]]`
- threshold-tuned test: `test_accuracy=0.9934`
- threshold-tuned test confusion matrix: `[[53, 1], [0, 97]]`

## Known failure modes

- trained on one local source only, without an external clinical holdout
- likely overlap with other red-eye causes that are not labeled separately in
  this dataset
- should only narrow some `surface_abnormal` cases, not replace the full
  fallback branch
- should still be presented as an evaluation artifact until broader validation
  is completed
