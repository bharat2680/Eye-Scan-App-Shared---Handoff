# anterior_eyelid_abnormality_vs_normal_v1_simplecnn

## Files

- `best_model.keras`
- `label_map.json`
- `train_config.json`
- `metrics.json`
- `inference_contract.json`

## Intended use

Use only after the anterior quality gate and only if eyelid findings remain in
scope for the product. This model separates:

- `eyelid_abnormality`
- `normal`

It is best treated as an optional branch rather than a direct replacement for
the current surface-positive fallback.

## Preprocessing

- color mode: RGB
- input size: `224 x 224`
- resize: direct resize to `224 x 224`
- dtype: `float32`
- normalization: the model includes `Rescaling(1.0 / 255.0)` internally, so
  pass raw RGB image values and do not normalize twice upstream

## Decision rule

- recommended positive label: `eyelid_abnormality`
- recommended threshold: `0.35` on `p(eyelid_abnormality)`
- threshold selected on validation split for balanced accuracy
- fallback if threshold logic is unavailable: `argmax`

## Metrics summary

- validation: `val_accuracy=0.9205`, `val_loss=0.2539`
- threshold-tuned validation balanced accuracy: `0.9247`
- default test: `test_accuracy=0.9318`
- default test confusion matrix: `[[72, 7], [5, 92]]`
- threshold-tuned test: `test_accuracy=0.9261`
- threshold-tuned test confusion matrix: `[[74, 5], [8, 89]]`

## Known failure modes

- trained on one local source only, without an external clinical holdout
- not a clean surface-only head and depends on eyelid visibility in framing
- the selected validation threshold generalized slightly worse than plain
  `argmax` on the held-out local test split
- should remain evaluation-only and optional
