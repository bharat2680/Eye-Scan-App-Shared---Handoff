# anterior_pterygium_vs_normal_v1_simplecnn

## Files

- `best_model.keras`
- `label_map.json`
- `train_config.json`
- `metrics.json`
- `inference_contract.json`

## Intended use

Use only after the anterior quality gate and only on images already classified
as `surface_abnormal` by the current surface model. This model separates:

- `pterygium`
- `normal`

It is intended to narrow some surface-positive cases. It is not a general
anterior disease classifier.

## Preprocessing

- color mode: RGB
- input size: `224 x 224`
- resize: direct resize to `224 x 224`
- dtype: `float32`
- normalization: the model includes `Rescaling(1.0 / 255.0)` internally, so
  pass raw RGB image values and do not normalize twice upstream

## Decision rule

- recommended positive label: `pterygium`
- recommended threshold: `0.05` on `p(pterygium)`
- threshold selected on validation split for balanced accuracy
- fallback if threshold logic is unavailable: `argmax`

## Metrics summary

- validation: `val_accuracy=1.0000`, `val_loss=0.0262`
- threshold-tuned validation balanced accuracy: `1.0000`
- default test: `test_accuracy=1.0000`
- default test confusion matrix: `[[97, 0], [0, 15]]`
- threshold-tuned test: `test_accuracy=1.0000`
- threshold-tuned test confusion matrix: `[[97, 0], [0, 15]]`

## Known failure modes

- trained on one local source only, without an external clinical holdout
- current local support is very small with only `72` positive train images and
  `15` positive test images
- should remain evaluation-only until broader validation is completed
